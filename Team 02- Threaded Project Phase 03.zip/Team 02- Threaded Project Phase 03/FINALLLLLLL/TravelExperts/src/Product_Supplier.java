//Garrett
public class Product_Supplier {
	
	private int SupplierId;
	private String SupName;
	private int ProductSupplierId;
	private int ProductId;
	private String ProdName;
	
	public Product_Supplier() { }

	public int getSupplierId() {
		return SupplierId;
	}

	public void setSupplierId(int supplierId) {
		SupplierId = supplierId;
	}

	public String getSupName() {
		return SupName;
	}

	public void setSupName(String supName) {
		SupName = supName;
	}

	public int getProductSupplierId() {
		return ProductSupplierId;
	}

	public void setProductSupplierId(int productSupplierId) {
		ProductSupplierId = productSupplierId;
	}

	public int getProductId() {
		return ProductId;
	}

	public void setProductId(int productId) {
		ProductId = productId;
	}

	public String getProdName() {
		return ProdName;
	}

	public void setProdName(String prodName) {
		ProdName = prodName;
	}

	@Override
	public String toString() {
		return SupName;
	}
	
	
	
	
}
