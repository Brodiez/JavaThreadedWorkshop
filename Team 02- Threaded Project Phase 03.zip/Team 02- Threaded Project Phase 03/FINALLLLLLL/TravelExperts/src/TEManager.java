import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageInputStream;
import javax.imageio.stream.ImageInputStream;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class TEManager extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TEManager frame = new TEManager();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TEManager() {
		setTitle("Travel Experts Manager");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 641, 484);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnPackages = new JButton("Packages");
		btnPackages.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmPackages packagesfrm = new frmPackages();
				packagesfrm.setLocationRelativeTo(null);
				packagesfrm.setVisible(true);
			}
		});
		btnPackages.setBounds(417, 231, 137, 41);
		contentPane.add(btnPackages);
		
		JButton btnAgents = new JButton("Agents");
		btnAgents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AgentForm agent = new AgentForm();
				agent.setLocationRelativeTo(null);
				agent.setVisible(true);
			}
		});
		btnAgents.setBounds(417, 151, 137, 41);
		contentPane.add(btnAgents);
		
		JButton btnCustomers = new JButton("Customers");
		btnCustomers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				customer_form_EDIT_DELETE frmCustomer = new customer_form_EDIT_DELETE();
				frmCustomer.setLocationRelativeTo(null);
				frmCustomer.setVisible(true);
			}
		});
		btnCustomers.setBounds(417, 72, 137, 41);
		contentPane.add(btnCustomers);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(417, 358, 137, 41);
		contentPane.add(btnExit);
		
		BufferedImage myPicture;
		try {
			myPicture = ImageIO.read(new File("splashscreen.jpg"));
			JLabel picLabel = new JLabel(new ImageIcon(myPicture));
			picLabel.setBounds(45, 70, 320, 264);
			
			//picLabel.setBounds(0, 151, 177, -151);
			getContentPane().add(picLabel);
			picLabel.setVisible(true);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
}
