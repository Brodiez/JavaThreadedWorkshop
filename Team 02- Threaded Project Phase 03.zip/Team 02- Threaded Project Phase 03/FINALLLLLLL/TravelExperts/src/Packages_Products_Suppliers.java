//Garrett
public class Packages_Products_Suppliers {
	
	private int PackageId;
	private int ProductSupplierId;
	
	
	public Packages_Products_Suppliers() {	}


	public int getPackageId() {
		return PackageId;
	}


	public void setPackageId(int packageId) {
		PackageId = packageId;
	}


	public int getProductSupplierId() {
		return ProductSupplierId;
	}


	public void setProductSupplierId(int productSupplierId) {
		ProductSupplierId = productSupplierId;
	}
	
	
	
	

}
